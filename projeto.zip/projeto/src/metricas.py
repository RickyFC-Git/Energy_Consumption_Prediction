import numpy as np


def mae(y, p): return float(np.mean(np.abs(y - p)))
def rmse(y, p): return float(np.sqrt(np.mean((y - p) ** 2)))
def r2(y, p): return float(1 - np.sum((y - p) ** 2) / np.sum((y - y.mean()) ** 2))


def todas(y, p):
    return {"MAE": mae(y, p), "RMSE": rmse(y, p), "R2": r2(y, p)}

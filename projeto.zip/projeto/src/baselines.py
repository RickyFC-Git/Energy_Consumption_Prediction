"""Baselines simples para t+1. Usam apenas o historico em kWh (sem aprendizagem)."""
import numpy as np


def persistencia(j):            # valor da hora anterior (t)
    return j.lags_kwh[:, -1]


def mesma_hora_dia_anterior(j):  # t+1-24
    return j.lags_kwh[:, -24]


def mesma_hora_semana_anterior(j):  # t+1-168
    return j.lags_kwh[:, -168]


BASELINES = {
    "Persistência (t)": persistencia,
    "Mesma hora, dia anterior": mesma_hora_dia_anterior,
    "Mesma hora, semana anterior": mesma_hora_semana_anterior,
}

"""MLP, CNN 1D e LSTM em PyTorch, treino com early stopping na validação."""
import time
import numpy as np
import torch
import torch.nn as nn

torch.set_num_threads(2)


def _feats_hora(h):
    ang = 2 * np.pi * h / 24
    return np.stack([np.sin(ang), np.cos(ang)], 1).astype("float32")


class MLP(nn.Module):
    def __init__(self, L, oc=64):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(L + 2, oc), nn.ReLU(), nn.Linear(oc, oc // 2), nn.ReLU(), nn.Linear(oc // 2, 1))

    def forward(self, x, hh):
        return self.net(torch.cat([x, hh], 1)).squeeze(1)


class CNN1D(nn.Module):
    def __init__(self, L, oc=32):
        super().__init__()
        self.conv = nn.Sequential(nn.Conv1d(1, oc, 5, padding=2), nn.ReLU(), nn.MaxPool1d(2),
                                  nn.Conv1d(oc, oc, 5, padding=2), nn.ReLU(), nn.AdaptiveAvgPool1d(8))
        self.head = nn.Sequential(nn.Linear(oc * 8 + 2, 32), nn.ReLU(), nn.Linear(32, 1))

    def forward(self, x, hh):
        z = self.conv(x.unsqueeze(1)).flatten(1)
        return self.head(torch.cat([z, hh], 1)).squeeze(1)


class LSTM(nn.Module):
    def __init__(self, L, oc=32):
        super().__init__()
        self.rnn = nn.LSTM(1, oc, batch_first=True)
        self.head = nn.Sequential(nn.Linear(oc + 2, 32), nn.ReLU(), nn.Linear(32, 1))

    def forward(self, x, hh):
        # LSTM sobre as ultimas 48 h (mais barato que 168 e suficiente para o ciclo diario)
        o, _ = self.rnn(x[:, -48:].unsqueeze(2))
        return self.head(torch.cat([o[:, -1], hh], 1)).squeeze(1)


ARQS = {"MLP": MLP, "CNN 1D": CNN1D, "LSTM": LSTM}


def _t(j):
    return torch.tensor(j.X, dtype=torch.float32), torch.tensor(_feats_hora(j.h)), torch.tensor(j.y, dtype=torch.float32)


def prever(m, j, bs=2048):
    m.eval()
    X, H, _ = _t(j)
    with torch.no_grad():
        return torch.cat([m(X[i:i + bs], H[i:i + bs]) for i in range(0, len(X), bs)]).numpy()


def treinar(nome, oc, treino, val, seed, L, max_ep=60, paciencia=8, lr=1e-3, bs=128):
    torch.manual_seed(seed); np.random.seed(seed)
    m = ARQS[nome](L, oc)
    opt = torch.optim.Adam(m.parameters(), lr=lr)
    Xt, Ht, yt = _t(treino)
    best, best_state, esp = 1e9, None, 0
    t0 = time.perf_counter()
    for ep in range(max_ep):
        m.train()
        perm = torch.randperm(len(Xt))
        for i in range(0, len(perm), bs):
            b = perm[i:i + bs]
            opt.zero_grad()
            loss = nn.functional.mse_loss(m(Xt[b], Ht[b]), yt[b])
            loss.backward(); opt.step()
        v = float(np.mean((prever(m, val) - val.y) ** 2))   # escolha SÓ pela validação
        if v < best - 1e-6:
            best, esp = v, 0
            best_state = {k: x.clone() for k, x in m.state_dict().items()}
        else:
            esp += 1
            if esp >= paciencia:
                break
    tempo_treino = time.perf_counter() - t0
    m.load_state_dict(best_state)
    return m, best, tempo_treino, ep + 1


def n_params(m):
    return sum(p.numel() for p in m.parameters())

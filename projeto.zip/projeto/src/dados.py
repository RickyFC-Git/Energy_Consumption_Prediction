"""Carregamento, segmentos, divisão cronológica, escalonamento e janelas (t+1)."""
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import pandas as pd

ANOS = (2019, 2020)


def carregar_segmentos(pasta, edificio="ABR", energia="elec"):
    """Devolve {ano: array kWh}. Cada ficheiro é um segmento independente:
    não há timestamps no dataset, por isso nunca se juntam 2019 e 2020."""
    segs = {}
    for ano in ANOS:
        f = Path(pasta) / f"UVTgv_{energia}_demand_building_{edificio}_{ano}.csv"
        segs[ano] = pd.read_csv(f)["kWh"].to_numpy(dtype=float)
    return segs


@dataclass
class Janelas:
    X: np.ndarray        # (n, L) consumo escalonado das L horas anteriores
    h: np.ndarray        # (n,) hora do dia da hora a prever (0-23), assumindo idx%24
    y: np.ndarray        # (n,) alvo escalonado
    y_kwh: np.ndarray    # (n,) alvo em kWh
    lags_kwh: np.ndarray # (n, L) historico em kWh (para baselines)
    seg: np.ndarray      # (n,) ano do segmento
    idx: np.ndarray      # (n,) posicao da hora alvo dentro do segmento


def dividir(segs, L=168, frac=(0.70, 0.15, 0.15), modo="por_segmento"):
    """Atribui cada hora-alvo a treino/val/teste de forma cronológica.

    por_segmento: em cada ano, os primeiros 70% das horas são treino, os 15%
                  seguintes validação e os últimos 15% teste.
    ano:          treino/val em 2019 (85/15) e teste = 2020 inteiro (teste de stress
                  à mudança de regime).
    Os alvos só existem a partir da hora L de cada segmento, por isso nenhuma
    janela atravessa a junção 2019/2020."""
    zonas = {"treino": [], "val": [], "teste": []}
    for ano, s in segs.items():
        n = len(s)
        alvos = np.arange(L, n)
        if modo == "por_segmento":
            a, b = int(frac[0] * n), int((frac[0] + frac[1]) * n)
            z = np.where(alvos < a, "treino", np.where(alvos < b, "val", "teste"))
        else:
            if ano == 2019:
                b = int(0.85 * n)
                z = np.where(alvos < b, "treino", "val")
            else:
                z = np.array(["teste"] * len(alvos))
        for nome in zonas:
            zonas[nome].append((ano, alvos[z == nome]))
    return zonas


def construir(segs, zonas, L=168):
    """Escalonador ajustado SÓ nos alvos de treino; devolve Janelas por zona + (mu, sd)."""
    treino_vals = np.concatenate([segs[a][i] for a, i in zonas["treino"]])
    mu, sd = treino_vals.mean(), treino_vals.std()
    out = {}
    for nome, lista in zonas.items():
        Xs, hs, ys, yk, lg, sg, ix = [], [], [], [], [], [], []
        for ano, alvos in lista:
            s = segs[ano]
            if len(alvos) == 0:
                continue
            mat = np.stack([s[i - L:i] for i in alvos])
            Xs.append((mat - mu) / sd)
            lg.append(mat)
            hs.append(alvos % 24)
            ys.append((s[alvos] - mu) / sd)
            yk.append(s[alvos])
            sg.append(np.full(len(alvos), ano))
            ix.append(alvos)
        out[nome] = Janelas(*[np.concatenate(v) for v in (Xs, hs, ys, yk, lg, sg, ix)])
    return out, (mu, sd)

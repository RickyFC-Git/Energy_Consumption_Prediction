# Previsão t+1 do consumo — E-LAND UVTgv

Pipeline: dados por segmentos -> divisão cronológica -> baselines -> MLP / CNN 1D / LSTM -> métricas, análise de erros e custo.

## Como correr
    pip install -r requirements.txt
    python run.py --pasta <caminho>/UVTgv_OD/demand --edificio ABR --energia elec
    # outros: --edificio C|ICSTM, --energia heat, --modo ano (teste = 2020 inteiro), --seeds 3

Saídas em `resultados/<edificio>_<energia>_<modo>/`: métricas de teste, custo computacional (parâmetros, tempo de treino e de inferência), erros nos picos, MAE por hora, previsões e 3 gráficos.

## Decisões de método (e porquê)
- **Segmentos.** O dataset não tem timestamps e cada ficheiro tem 8760 h. 2019 e 2020 são segmentos separados; nenhuma janela os atravessa (os alvos começam na hora L de cada segmento).
- **Entradas.** Só as L=168 h anteriores de consumo + hora do dia em seno/coseno. Sem dia da semana, porque o alinhamento do início dos ficheiros não está confirmado (ver `00_verificar_alinhamento.png`).
- **Divisão.** `por_segmento`: em cada ano 70% treino, 15% validação, 15% teste, por ordem temporal. `ano`: treino/validação em 2019 e teste em 2020 (stress à mudança de regime).
- **Escalonamento.** Média e desvio-padrão só do treino.
- **Seleção.** Largura da rede escolhida só pelo erro de validação (seed 0), com paragem antecipada; depois N sementes, com média e desvio-padrão no teste.
- **Baselines.** Persistência (t), mesma hora do dia anterior (t-24) e mesma hora da semana anterior (t-168).
- **Métricas.** MAE, RMSE e R² em kWh (sem MAPE, porque há zeros no ICSTM e na energia térmica).
- **Erros.** MAE por hora do dia e subestimação dos 5% maiores picos.

## Primeiro resultado (ABR, eletricidade, por_segmento, 2 sementes)
| Modelo | MAE | RMSE | R² |
|---|---|---|---|
| Persistência (t) | 2,77 | 5,96 | 0,961 |
| Mesma hora, dia anterior | 7,92 | 15,24 | 0,744 |
| Mesma hora, semana anterior | 10,11 | 17,14 | 0,676 |
| MLP | 3,03 | 5,09 | 0,971 |
| CNN 1D | 2,82 | 4,55 | 0,977 |
| LSTM | 3,03 | 5,16 | 0,971 |

Em t+1 horário a persistência é muito forte: os modelos só ganham no RMSE (e a CNN 1D por pouco no R²) e não ganham no MAE. Isto é resultado, não erro, e é o que o relatório deve discutir.

## Limitações conhecidas
- A hora do dia assume que cada ficheiro começa às 00:00 (idx % 24). Confirmar nos gráficos.
- Hiperparâmetros: só 2 larguras por modelo. Alargar a grelha (camadas, janela L, taxa de aprendizagem) usando apenas a validação.
- Falta correr C, ICSTM, calor e `--modo ano`, e tratar os dias planos/zeros do ICSTM 2020.
- Falta o protótipo/dashboard.

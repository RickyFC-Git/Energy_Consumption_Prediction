"""Pipeline t+1: python run.py --pasta <UVTgv_OD/demand> --edificio ABR --energia elec"""
import argparse, time, json
from pathlib import Path
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from src import dados, baselines, modelos, metricas

p = argparse.ArgumentParser()
p.add_argument("--pasta", required=True)
p.add_argument("--edificio", default="ABR")
p.add_argument("--energia", default="elec", choices=["elec", "heat"])
p.add_argument("--modo", default="por_segmento", choices=["por_segmento", "ano"])
p.add_argument("--L", type=int, default=168)
p.add_argument("--seeds", type=int, default=3)
p.add_argument("--saida", default="resultados")
a = p.parse_args()

tag = f"{a.edificio}_{a.energia}_{a.modo}"
out = Path(a.saida) / tag; out.mkdir(parents=True, exist_ok=True)

segs = dados.carregar_segmentos(a.pasta, a.edificio, a.energia)
zonas = dados.dividir(segs, a.L, modo=a.modo)
J, (mu, sd) = dados.construir(segs, zonas, a.L)
tr, va, te = J["treino"], J["val"], J["teste"]
print(f"{tag}: treino={len(tr.y)} val={len(va.y)} teste={len(te.y)} | zeros no teste: {(te.y_kwh == 0).sum()}")

# --- verificação visual do alinhamento (primeiras 4 semanas de cada ano) ---
fig, ax = plt.subplots(2, 1, figsize=(11, 5))
for k, ano in enumerate(dados.ANOS):
    ax[k].plot(segs[ano][:24 * 28], lw=.8)
    for d in range(0, 28):
        ax[k].axvline(d * 24, color="grey", lw=.3)
    ax[k].set_title(f"{a.edificio} {a.energia} {ano}: primeiras 4 semanas (linhas = início de cada 'dia' do ficheiro)")
plt.tight_layout(); plt.savefig(out / "00_verificar_alinhamento.png", dpi=110); plt.close()

# --- baselines ---
linhas, previsoes = [], {}
for nome, f in baselines.BASELINES.items():
    pr = f(te); previsoes[nome] = pr
    linhas.append({"modelo": nome, "tipo": "baseline", **metricas.todas(te.y_kwh, pr)})

# --- modelos: hiperparâmetro escolhido SÓ na validação (seed 0), depois N sementes ---
GRELHA = {"MLP": [32, 64], "CNN 1D": [16, 32], "LSTM": [16, 32]}
custo = []
for nome, oc_list in GRELHA.items():
    val_scores = {}
    for oc in oc_list:
        _, v, _, _ = modelos.treinar(nome, oc, tr, va, 0, a.L)
        val_scores[oc] = v
    oc_best = min(val_scores, key=val_scores.get)
    print(f"{nome}: val MSE por oc {val_scores} -> oc={oc_best}")
    preds, res = [], []
    for s in range(a.seeds):
        m, v, tt, ep = modelos.treinar(nome, oc_best, tr, va, s, a.L)
        t0 = time.perf_counter(); pr = modelos.prever(m, te) * sd + mu; ti = (time.perf_counter() - t0) / len(te.y) * 1e3
        res.append(metricas.todas(te.y_kwh, pr)); preds.append(pr)
        custo.append({"modelo": nome, "seed": s, "parametros": modelos.n_params(m), "treino_s": tt, "epocas": ep, "inferencia_ms_por_amostra": ti})
    df = pd.DataFrame(res)
    linhas.append({"modelo": nome, "tipo": f"DL (oc={oc_best}, {a.seeds} sementes)",
                   **{k: df[k].mean() for k in df}, **{k + "_std": df[k].std() for k in df}})
    previsoes[nome] = np.mean(preds, 0)

R = pd.DataFrame(linhas)
R.to_csv(out / "metricas_teste.csv", index=False)
pd.DataFrame(custo).to_csv(out / "custo_computacional.csv", index=False)

# --- análise de erros ---
T = pd.DataFrame({"seg": te.seg, "idx": te.idx, "hora": te.h, "real": te.y_kwh})
T["dia_bloco"] = T["idx"] // 24
lim_pico = np.quantile(te.y_kwh, 0.95)
erros = []
for nome, pr in previsoes.items():
    e = pr - te.y_kwh
    T[nome] = pr
    pico = te.y_kwh >= lim_pico
    erros.append({"modelo": nome, "erro_medio_(sub<0)": e.mean(),
                  "erro_medio_nos_picos_5%": e[pico].mean(),
                  "%_picos_subestimados": float((e[pico] < 0).mean() * 100)})
pd.DataFrame(erros).to_csv(out / "erros_picos.csv", index=False)
T.to_csv(out / "previsoes_teste.csv", index=False)

h = pd.DataFrame({n: np.abs(T[n] - T["real"]).groupby(T["hora"]).mean() for n in previsoes})
h.to_csv(out / "mae_por_hora.csv")
ax = h.plot(figsize=(10, 4), title="MAE por hora do dia (teste)"); ax.set_ylabel("kWh")
plt.tight_layout(); plt.savefig(out / "01_mae_por_hora.png", dpi=110); plt.close()

# semana de exemplo do teste (a primeira de cada segmento de teste)
ex = T.iloc[:24 * 7]
ax = ex.plot(x="idx", y=["real", "Mesma hora, semana anterior", "MLP", "LSTM"], figsize=(11, 4),
             title="Teste: primeira semana (real vs. previsões)")
plt.tight_layout(); plt.savefig(out / "02_exemplo_semana.png", dpi=110); plt.close()

print(R.round(3).to_string(index=False))
print(pd.DataFrame(erros).round(3).to_string(index=False))
print(json.dumps({"mu": mu, "sd": sd}))
